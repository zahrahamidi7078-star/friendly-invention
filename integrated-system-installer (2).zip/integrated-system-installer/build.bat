@echo off
chcp 65001 >nul
echo ===== ساخت فایل نصبی =====
where node >nul 2>nul || (echo Node.js نصب نیست. از https://nodejs.org نسخه LTS را نصب کنید و دوباره اجرا کنید. & pause & exit /b 1)
call npm install || (echo خطا در npm install & pause & exit /b 1)
call npm run dist || (echo خطا در ساخت & pause & exit /b 1)
echo.
echo انجام شد. فایل نصبی در پوشه dist ساخته شد.
start "" dist
pause
